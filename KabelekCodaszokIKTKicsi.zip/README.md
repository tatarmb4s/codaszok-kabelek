# Codászok kábelekről szóló leírása
 A Neumann János Informatikai technikum 2021-es tanévében a Számitógép alkatrészeinek kábeles projektje.

 # Tennivalók:
<!-- blank line -->
----
<!-- blank line -->
## Menüpontok:
 - Képátviteli kábelek
 - USB Kábelek
 - Hálózati kábelek
 - Táp kábelek
 - (Egyéb kábelek, de ezen még gonlokozom hogy mi lehet bele)

## Fontok:

 - **Menü**:     [Nunito][nunito-font] <br>
 - **H2**:       [Lora] <br>
 - **H1**:       [Encode-Sans][encoce-sans] <br>
 - **Text**:     [Hamlet] <br>
 - **Examples**: [Top 20 Google font][google-top20font]


[nunito-font]:https://fonts.google.com/specimen/Nunito#standard-styles
[lora]:https://fonts.google.com/specimen/Lora
[encoce-sans]:https://fonts.google.com/specimen/Encode+Sans
[Hamlet]:https://fonts.google.com/specimen/Hahmlet
[google-top20font]:https://www.awwwards.com/20-best-web-fonts-from-google-web-fonts-and-font-face.html
